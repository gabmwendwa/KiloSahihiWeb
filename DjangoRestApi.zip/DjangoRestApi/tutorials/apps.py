from django.apps import AppConfig


class TutorialsConfig(AppConfig):
    name = 'tutorials'
